var http = require('http');
var port = 9000;
var hostname = 'localhost';
//1.创建磁盘路径处理的模块（绝对路径）
var path = require('path');
//2.用文件系统读index.html文件的内容,就是操作文件、目录的模块
var fs = require('fs');
//5.处理url的模块
var url = require('url');
http.createServer(function (request, response) {
    //4.得到index.css路径
    var urlObj = url.parse(request.url);//将字符串转对象
    //6.用path处理static的绝对路径
    var staticPath = path.join(__dirname, 'static')//join方法拼接两个路径字符串
    //7.加一个判断
    if (urlObj.pathname === '/') {
        urlObj.pathname += 'index.html'
    }
    console.log(urlObj.pathname)
    //8.
    var filePath = path.join(staticPath, urlObj.pathname);

    fs.readFile(filePath, 'binary', function (error, filecontent) {
        if (error) {
            throw error
        } else {
            response.write(filecontent, 'binary')
            response.end()
        }
    })

}).listen(port, hostname, function () {
    console.log(`The server running in:http://${hostname}:${port}`)
})
